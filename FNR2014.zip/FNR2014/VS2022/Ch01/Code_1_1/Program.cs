﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_1_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int n = 1; n < 6; n++)
            {
                Console.WriteLine("2^" + n.ToString() + " = " + Power(2, n).ToString());
            }

            Console.ReadKey();
        }

        static double Power(double x, double n)
        {
            double p = Math.Exp(n * Math.Log(x));
            return p;
        }

    }
}

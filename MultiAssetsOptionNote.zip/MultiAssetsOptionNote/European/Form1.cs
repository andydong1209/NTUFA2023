﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

using DFinMath;

namespace European
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // European 3 Assets Option
        private void button2_Click(object sender, EventArgs e)
        {
            MersenneTwister MT = new MersenneTwister(1234);
            Stopwatch SW = new Stopwatch();
            SW.Start();

            int NumAsset = 3;
            int NPath = 100000;
            int MStep = 1;

            double S1 = 40.0;
            double S2 = 40.0;
            double S3 = 40.0;

            double sig1 = 0.2;
            double sig2 = 0.3;
            double sig3 = 0.5;
            double rate = 0.05;
            double corr = 0.5;

            int Month = 1;
            double TTM = Month / 12.0;
            //MStep = Month * 30;
            MStep = 1;
            double dt = TTM / MStep;
            double K = 35.0;

            Matrix MCorr = new Matrix(3, 3, corr);
            for (int i = 0; i < NumAsset; i++)
            {
                MCorr[i, i] = 1.0;
            }

            Matrix MLow = MatrixUtilities.CholeskyDecomposition(MCorr, true);
            listBox1.Items.Add("Cholesky Decomposition: ");
            listBox1.Items.Add(MLow[0, 0].ToString("F4") + " : " 
                + MLow[0, 1].ToString("F4") + " : " + MLow[0, 2].ToString("F4"));
            listBox1.Items.Add(MLow[1, 0].ToString("F4") + " : " 
                + MLow[1, 1].ToString("F4") + " : " + MLow[1, 2].ToString("F4"));
            listBox1.Items.Add(MLow[2, 0].ToString("F4") + " : " 
                + MLow[2, 1].ToString("F4") + " : " + MLow[2, 2].ToString("F4"));

            List<Matrix> LMS = new List<Matrix>(0);
            Matrix MS1 = new Matrix(NPath, MStep + 1, 0.0);
            Matrix MS2 = new Matrix(NPath, MStep + 1, 0.0);
            Matrix MS3 = new Matrix(NPath, MStep + 1, 0.0);
            Vector VCT = new Vector(NPath, 0.0);

            for (int i = 0; i < NPath; i++)
            {
                MS1[i, 0] = S1;
                MS2[i, 0] = S2;
                MS3[i, 0] = S3;
                for (int j = 0; j < MStep; j++)
                {
                    double n1 = DStat.N_Inv(MT.NextDouble());
                    double n2 = DStat.N_Inv(MT.NextDouble());
                    double n3 = DStat.N_Inv(MT.NextDouble());

                    double e1 = n1 * MLow[0, 0];
                    double e2 = n1 * MLow[1, 0] + n2 * MLow[1, 1];
                    double e3 = n1 * MLow[2, 0] + n2 * MLow[2, 1] + n3 * MLow[2, 2];

                    MS1[i, j + 1] = MS1[i, j] * Math.Exp((rate - 0.5 * sig1 * sig1) * dt + sig1 * Math.Sqrt(dt) * e1);
                    MS2[i, j + 1] = MS2[i, j] * Math.Exp((rate - 0.5 * sig2 * sig2) * dt + sig2 * Math.Sqrt(dt) * e2);
                    MS3[i, j + 1] = MS3[i, j] * Math.Exp((rate - 0.5 * sig3 * sig3) * dt + sig3 * Math.Sqrt(dt) * e3);
                }

                double MaxST = Math.Max(Math.Max(MS1[i, MStep], MS2[i, MStep]), MS3[i, MStep]);

                VCT[i] = Math.Max(0.0, MaxST - K);
            }

            double SumCT = 0.0;            
            for (int i = 0; i< NPath; i++)
            {
                SumCT = SumCT + VCT[i];
            }

            double AvgCT = SumCT / NPath;
            double C0 = AvgCT * Math.Exp(-rate * TTM);
            SW.Stop();

            double expect = 7.78;
            textBox1.Text = C0.ToString(); // 7.7678
            textBox2.Text = SW.ElapsedMilliseconds.ToString();
            textBox3.Text = expect.ToString();
            textBox4.Text = ((C0 - expect) / S1).ToString("F6");
        }
    }
}
